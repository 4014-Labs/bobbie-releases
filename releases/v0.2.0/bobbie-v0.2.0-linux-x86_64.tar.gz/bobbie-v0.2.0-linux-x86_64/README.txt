# Bobbie Binary Install

This file is intended to ship inside Bobbie release archives.

## Archive contents

A Bobbie release archive should include:

- `bin/bobbie`
- `LICENSE.md`
- `COMMERCIAL.md`
- this install note

## Quick start

```bash
./bin/bobbie --license
./bin/bobbie --help
```

## Validate a pipeline

```bash
./bin/bobbie validate path/to/pass_001.spv path/to/pass_002.spv
```

## Render with external `ffmpeg`

```bash
ffmpeg -hide_banner -loglevel error -i input.mp4 -map 0:v:0 -f rawvideo -pix_fmt rgba - \
| ./bin/bobbie render \
    --input-pixels - \
    --output-pixels - \
    --pixel-format rgba8 \
    --width 1920 \
    --height 1080 \
    --fps-num 30000 \
    --fps-den 1001 \
    path/to/pass_001.spv \
| ffmpeg -hide_banner -loglevel error -f rawvideo -pix_fmt rgba -s:v 1920x1080 -r 30000/1001 -i - output.mp4
```

Bobbie does not decode or encode media containers directly. It is intended to
compose with external tools such as `ffmpeg` and `ffprobe`.
